public enum ItemType {
    LIFE_BOOST,
    PENALTY
}
